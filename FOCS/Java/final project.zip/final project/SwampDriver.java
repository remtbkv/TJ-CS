import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;


public class SwampDriver {

    public static void main(String[] args)
    {        
        JFrame frame = new JFrame("Swamp");
        frame.setSize(1200, 700);        
        SwampGUI s = new SwampGUI();
        Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((int) (size.getWidth()-1200)/2, (int) (size.getHeight()-700)/2);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(new SwampGUI());
        frame.setVisible(true);
    }
    
    
}