import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class battleGame extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private BufferedImage myImage;
   private Graphics myBuffer;
   private Kaneki k = new Kaneki(25, 320);
   private Shrek s = new Shrek(900, 300);
   private Health kh = new Health(25, 295, 60, 20);
   private Health sh = new Health(900, 245,170, 50);
   private Timer t;
   private Timer d = new Timer(500, new Damager());
   private Timer ck = new Timer(1000, new ShotTimer());
   private ImageIcon bg = new ImageIcon("images/match.png");
   private ImageIcon twin = new ImageIcon("images/win.png");
   private ImageIcon tlose = new ImageIcon("images/lose.png");
   private Arrow1 ar;
   private boolean one = false;
   private boolean two = false;
   private boolean three = false;
   private boolean four = false;
   private boolean canShoot = true;
   private boolean cA = false;
   private boolean flying = false;
   private boolean canDamage = true;
   private boolean winner = false;
   private boolean timerOn = false;
   private boolean trueWin;
   private boolean canDo = false;
   
   
   public battleGame()
   {
      myImage =  new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
      myBuffer = myImage.getGraphics();
      myBuffer.drawImage(bg.getImage(), 0, 0, 1200, 700, null);
      addKeyListener(new Key()); 
      setFocusable(true); 
      k.draw(myBuffer);
      s.draw(myBuffer);
      kh.draw(myBuffer);
      sh.draw(myBuffer);
      k.setBattle();
      t = new Timer(5, new AnimationListener()); 
   }
   
   public boolean getWinner()
   {
      return winner;
   }
   
   private class ShotTimer implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         canShoot = true;
      }
   }
   
   public void animate()
   {
      k.move();
      s.move();
      if (cA)
      {
         ar.checkR(k);
         flying = true;
         cA = false;
      }
      if (flying)
      {
         ar.move();
         if (ar.hitEnemy(s))
         {
            ar = null;
            flying = false;
            if (canDamage)
            {
               sh.setHealth();
               canDamage = false;
            }
         }
         if (ar != null && ar.getX() + 24 > 1200)
         {
            ar = null;
            flying = false;
         }
         if (ar != null && ar.getX() < 0)
         {
            ar = null;
            flying = false;
         }
      }
      
      myBuffer.drawImage(bg.getImage(), 0, 0, 1200, 700, null);
      if (sh.death() == false)
      {
         sh.move();
      }
      else
      {
         winner = true;
         trueWin = true;
         t.stop();
         myBuffer.drawImage(twin.getImage(), 0, 0, 1200, 700, null);
         canDo = true;
         d.stop();
         setFocusable(false);
      }
      if (kh.death() == false)
      {
         kh.move();
      }
      else
      {
         winner = true;
         trueWin = false;
         t.stop();
         myBuffer.drawImage(tlose.getImage(), 0, 0, 1200, 700, null);
         canDo = true;
         d.stop();
         setFocusable(false);
      }
      k.draw(myBuffer);
      s.draw(myBuffer);
      kh.draw(myBuffer);
      sh.draw(myBuffer);
      if (flying)
      {
         ar.draw(myBuffer);
      }
      getArray();
      chase();
      deadCheck();
      repaint();
      if (canDo)
      {
         sh = null;
         k = null;
         s = null;
         ar = null;
         kh = null;
         if (trueWin)
         {
            myBuffer.drawImage(twin.getImage(), 0, 0, 1200, 700, null);
         }
         else
         {
            myBuffer.drawImage(tlose.getImage(), 0, 0, 1200, 700, null);
         }
      }
   }
   
   public void chase()
   {
      int Okx = k.getX();
      int Oky = k.getY();
      int Okxs = s.getX();
      int Okys = s.getY();
      if (Okx >= Okxs)
      {
         s.changedx(1);
         sh.changedx(1);
      }
      else if (Okx < Okxs)
      {
         s.changedx(-1);
         sh.changedx(-1);
      }
      if (Oky >= Okys)
      {
         s.changedy(1);
         sh.changedy(1);
      }
      else if (Oky < Okys)
      {
         s.changedy(-1);
         sh.changedy(-1);
      }
   }
   
   
   public void paintComponent(Graphics g)   
   {
      g.drawImage(myImage, 0, 0, getWidth(), getHeight(), null);
   }
   
   public boolean getArray()
   {
      Color[][] arr;
      Color[][] left = new Color[4][40];
      Color[][] right = new Color[4][40];
      Color[][] up = new Color[40][4];
      Color[][] down = new Color[40][4];
   
      int countJ = 0;
      int countQ = 0;
   	
      for(int j = k.getX() - 4; j < k.getX(); j++)
      {
         for(int q = k.getY() + 10; q < k.getY() + 50; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            left[countJ][countQ] = new Color(rgb);
            if (countQ != 39)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 4; j ++)
      {
         for (int q = 0; q < 40; q ++)
         {
            Color tmp = left[j][q];
            if (tmp.getRed() == 2 && tmp.getBlue()== 2 && tmp.getGreen() == 2)
            {
               one = true;           
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 10; j < k.getX() + 50; j++)
      {
         for(int q = k.getY() - 4; q < k.getY(); q++)
         {
            if (q < 0)
            {
               q = 0;
            }
            int rgb = myImage.getRGB(j,q);        	
            up[countJ][countQ] = new Color(rgb);
            if (countQ != 3)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 40; j ++)
      {
         for (int q = 0; q < 4; q ++)
         {
            Color tmp = up[j][q];
            if (tmp.getRed() == 2 && tmp.getBlue()== 2 && tmp.getGreen() == 2)
            {
               two  = true;        
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 10; j < k.getX() + 50; j++)
      {
         for(int q = k.getY() + 60; q < k.getY() + 64; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            down[countJ][countQ] = new Color(rgb);
            if (countQ != 3)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 40; j ++)
      {
         for (int q = 0; q < 4; q ++)
         {
            Color tmp = down[j][q];
            if (tmp.getRed() == 2 && tmp.getBlue()== 2 && tmp.getGreen() == 2)
            {
               three = true;        
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 60; j < k.getX() + 64; j++)
      {
         for(int q = k.getY() + 10; q < k.getY() + 50; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            right[countJ][countQ] = new Color(rgb);
            if (countQ != 39)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 4; j ++)
      {
         for (int q = 0; q < 40; q ++)
         {
            Color tmp = right[j][q];
            if (tmp.getRed() == 2 && tmp.getBlue()== 2 && tmp.getGreen() == 2)
            {
               four = true;   
            }
            
         }
      }
      if (one)
      {
         k.setX(3);
         kh.setX(3);
      }
      if (two)
      {
         k.setY(3);
         kh.setY(3);
      }
      if (three)
      {
         k.setY(-3);
         kh.setY(-3);
      }
      if (four)
      {
         k.setX(-3);
         kh.setX(-3); 
      }
      one = false;
      two = false;
      three = false;
      four = false;
      return false;
   }
   
   /*
   public void begin()
   {
      t.start();
      d.start();
   }
   */
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   public void deadCheck()
   {
      if (kh.death())
      {
         t.stop();
         d.stop();
      }
      else
      {
         ;
      }
   }
   
   public void damageCheckK()
   {
      if (s.damaged(k))
      {
         kh.setHealth();
      }
   }
   
   private class Damager implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         damageCheckK();
      }
   }
   
   private class Key extends KeyAdapter 
   {
      public void keyPressed(KeyEvent e)  
      {
         if (e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            if (timerOn == false)
            {
               t.start();
               d.start();
               timerOn = true;
            }
            k.changedy(4);
            kh.changedy(4);
         }
         if (e.getKeyCode() == KeyEvent.VK_UP)
         {
            if (timerOn == false)
            {
               t.start();
               d.start();
               timerOn = true;
            }
            k.changedy(-4);
            kh.changedy(-4);
         }
         if (e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            if (timerOn == false)
            {
               t.start();
               d.start();
               timerOn = true;
            }
            k.changedx(4);
            kh.changedx(4);
         }
         if (e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            if (timerOn == false)
            {
               t.start();
               d.start();
               timerOn = true;
            }
            k.changedx(-4);
            kh.changedx(-4);
         }
         if (e.getKeyCode() == KeyEvent.VK_SPACE && cA == false && flying == false)
         {
            //ck.stop();
            canDamage = true;
            cA = true;
            if (k.getDxx() >= 0)
            {
               ar = new Arrow1(k.getX() + 65, k.getY() + 30);
            }
            else
            {
               ar = new Arrow1(k.getX() - 5, k.getY() + 30);
            }
            flying = true;
            //canShoot = false;
            //ck.start();
            //draw arrow onto buffer and include in animate - then add the files together to have cohesive game. u good ez.
         }
      }
      public void keyReleased(KeyEvent e)
      {
         if(e.getKeyCode() == KeyEvent.VK_UP)
         {
            k.stopMovement();
            kh.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            k.stopMovement();
            kh.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            k.stopMovement();
            kh.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            k.stopMovement();
            kh.stopMovement();
         }
         if (e.getKeyCode() == KeyEvent.VK_SPACE)
         {
            k.stopMovement();
            kh.stopMovement();
         }
      }
      
   }


}