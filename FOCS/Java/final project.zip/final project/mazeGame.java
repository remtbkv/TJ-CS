import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;

public class mazeGame extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private BufferedImage myImage;
   private Graphics myBuffer;
   private Kaneki k = new Kaneki(520, 5);
   private Timer t;
   private int trueX;
   private int trueY;
   private ImageIcon maze = new ImageIcon("images/maze.jpg");
   private ImageIcon tester = new ImageIcon("images/3621.png");
   private ImageIcon tawf = new ImageIcon("images/2414.png");
   private ImageIcon ots = new ImageIcon("images/127.png");
   private Bitcoin btc = new Bitcoin();
   private boolean running = false;
   private boolean test = false;
   private boolean one = false;
   private boolean two = false;
   private boolean gameWon = false;
   private Bitcoin[] betc = new Bitcoin[10];
   private int moneyCount = 0;
   private int[] yex = new int[10];
   private int[] yy = new int[10];
   private boolean three = false;
   private boolean four = false;
   private boolean playerWins = false;
      
   public mazeGame()
   {
      myImage =  new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
      myBuffer = myImage.getGraphics();
      myBuffer.drawImage(ots.getImage(), 0, 0, 1200, 700, null);
      addKeyListener(new Key()); 
      setFocusable(true); 
      k.draw(myBuffer);
      t = new Timer(5, new AnimationListener()); 
      spawner();
   }
   
   
   public BufferedImage getBImage()
   {
      return myImage;
   }
   
   public boolean winner()
   {
      return playerWins;
   }
   
   public void animate()
   {
      k.move();
      myBuffer.drawImage(ots.getImage(), 0, 0, 1200, 700, null);
      k.draw(myBuffer);
      for (int x = 0; x < 10; x ++)
      {
         betc[x].draw(myBuffer);
         if (betc[x].collected(k))
         {           
            if (betc[x].canGive())
            {
               moneyCount += 1;
            }
            betc[x].gone();
         }
      }
      getArray();
      if (Checker())
      {
         t.stop();
         myBuffer.drawImage(ots.getImage(), 0, 0, 1200, 700, null);
      }
      repaint();
   }
   
   public void paintComponent(Graphics g)   
   {
      g.drawImage(myImage, 0, 0, getWidth(), getHeight(), null);
   }
   
   public int returnMoney()
   {
      return moneyCount;
   }
   
      
   public boolean getArray()
   {
      Color[][] arr;
      Color[][] left = new Color[4][40];
      Color[][] right = new Color[4][40];
      Color[][] up = new Color[40][4];
      Color[][] down = new Color[40][4];
   
      int countJ = 0;
      int countQ = 0;
   	
      for(int j = k.getX() - 4; j < k.getX(); j++)
      {
         for(int q = k.getY() + 10; q < k.getY() + 50; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            left[countJ][countQ] = new Color(rgb);
            if (countQ != 39)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 4; j ++)
      {
         for (int q = 0; q < 40; q ++)
         {
            Color tmp = left[j][q];
            if (tmp.getRed()==0)
            {
               one = true;           
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 10; j < k.getX() + 50; j++)
      {
         for(int q = k.getY() - 4; q < k.getY(); q++)
         {
            if (q < 0)
            {
               q = 0;
            }
            int rgb = myImage.getRGB(j,q);        	
            up[countJ][countQ] = new Color(rgb);
            if (countQ != 3)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 40; j ++)
      {
         for (int q = 0; q < 4; q ++)
         {
            Color tmp = up[j][q];
            if (tmp.getRed()==0)
            {
               two  = true;        
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 10; j < k.getX() + 50; j++)
      {
         for(int q = k.getY() + 60; q < k.getY() + 64; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            down[countJ][countQ] = new Color(rgb);
            if (countQ != 3)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 40; j ++)
      {
         for (int q = 0; q < 4; q ++)
         {
            Color tmp = down[j][q];
            if (tmp.getRed()==0 || tmp.getBlue() > 200 && tmp.getRed() < 100)
            {
               if (tmp.getBlue() > 200)
               {
                  gameWon = true;
                  playerWins = true;
               }
               else
               {
                  three = true;        
               }
            }
         }
      }
      countQ = 0;
      countJ = 0;
      for(int j = k.getX() + 60; j < k.getX() + 64; j++)
      {
         for(int q = k.getY() + 10; q < k.getY() + 50; q++)
         {
            int rgb = myImage.getRGB(j,q);        	
            right[countJ][countQ] = new Color(rgb);
            if (countQ != 39)
            {
               countQ += 1;
            }
            else
            {
               countQ = 0;
            }
         }
         countJ += 1;
      }
      for (int j = 0; j < 4; j ++)
      {
         for (int q = 0; q < 40; q ++)
         {
            Color tmp = right[j][q];
            if (tmp.getRed()==0)
            {
               four = true;   
            }
            
         }
      }
      if (one)
      {
         k.setX(3);
      }
      if (two)
      {
         k.setY(3);
      }
      if (three)
      {
         k.setY(-3);
      }
      if (four)
      {
         k.setX(-3); 
      }
      one = false;
      two = false;
      three = false;
      four = false;
      return false;
   }
      
   public void moveKaneki(int dx, int dy)
   {
      k.move(dx, dy);
      myBuffer.drawImage(ots.getImage(), 0, 0, 1200, 700, null);
      k.draw(myBuffer);
      repaint();
   }
   
   public boolean Checker()
   {
      return gameWon;
   }
   
  
   public int[] coinGeneratorX()
   {
   
      Random r = new Random();
      for (int j = 0; j < 10; j ++)
      {
         int ex = r.nextInt(1200);
         yex[j] = ex;
      }
      return yex;
   }
   
   public int[] coinGeneratorY()
   {
      Random r = new Random();
      for (int j = 0; j < 10; j ++)
      {
         int why = r.nextInt(700);
         yy[j] = why;
      }
      return yy;
   }
   
   public void spawner()
   {
      int[] x;
      int[] y;
      x = coinGeneratorX();
      y = coinGeneratorY();
      for (int a = 0; a < 10; a ++)
      {
         betc[a] = new Bitcoin(x[a], y[a]);
      }
   }
   
   public void begin()
   {
      t.start();
   }
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   
   
   
   private class Key extends KeyAdapter 
   {
      public void keyPressed(KeyEvent e)  
      {
         if (e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            k.changedy(3);
            running = true;
            test = false;
         }
         if (e.getKeyCode() == KeyEvent.VK_UP)
         {
            k.changedy(-3);
            running = true;
            test = false;
         }
         if (e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            k.changedx(3);
            running = true;
            test = false;
         }
         if (e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            k.changedx(-3);
            running = true;
            test = false;
         }
      }
      public void keyReleased(KeyEvent e)
      {
         if(e.getKeyCode() == KeyEvent.VK_UP)
         {
            k.stopMovement();
            running = false;
         }
         if(e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            k.stopMovement();
            running =false;
         }
         if(e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            k.stopMovement();
            running = false;
         }
         if(e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            k.stopMovement();
            running = false;
         }
         if (e.getKeyCode() == KeyEvent.VK_SPACE)
         {
            k.stopMovement();
            running = false;
         }
      }
      
   }
}




