import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Shrek extends JPanel
{
   private ImageIcon Shrek = new ImageIcon("images/shrekR.png");
   private ImageIcon ShrekL = new ImageIcon("images/shrekL.png");
   private int width = 170;
   private int height = 218;
   private int startX;
   private int startY;
   private int dxx = 0;
   private int dyy = 0;
   private int mydy;
   private int mydx;
   
   public Shrek()
   {
      
      startX = 600;
      startY = 30;
   }
   
   public Shrek(int x, int y)
   {
      startX = x;
      startY = y;
   }
   
   public void move()
   {
      startX += dxx;
      startY += dyy;
   }
   
   public boolean damaged(Kaneki k)
   {
      for (int x = getX(); x < getX() + width; x ++)
      {
         for (int y = getY(); y < getY() + height; y++)
         {
            for (int o = k.getX(); o < k.getX() + 60; o ++)
            {
               for (int j = k.getY(); j < k.getY() + 60; j ++)
               {
                  if (j == y && o == x)
                  {
                     return true;
                  }
               }
            }
         }
      }
      return false;
   }
   
   public void stopMovement()
   {
      dxx = 0;
      dyy = 0;
   }
   
   public void changedy(int y)
   {
      dyy = y;
   }
   
   public void changedx(int x)
   {
      dxx = x;
   }
   
   public int getX()
   {
      return startX;
   }
   
   public int getY()
   {
      return startY;
   }
   
   public void setY(int y)
   {
      startY += y;
   }
   
   public void setX(int x)
   {
      startX += x;
   }
   
   
   public void draw(Graphics g)
   {
      if (dxx >= 0)
      {
         g.drawImage(Shrek.getImage(), startX, startY, width, height, null);
      }
      else
      {
         g.drawImage(ShrekL.getImage(), startX, startY, width, height, null);
      }
   }
}