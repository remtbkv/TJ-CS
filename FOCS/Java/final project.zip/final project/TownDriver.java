import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;

public class TownDriver
{
   public static void main(String[] args)
   {
      JFrame f = new JFrame("Shrek's Swamp");
      f.setSize(1200,700);
      f.setLocation(0,0);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setContentPane(new TownPanel());
      f.setVisible(true);
   }
}


