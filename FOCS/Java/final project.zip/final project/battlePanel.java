import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class battlePanel extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private ImageIcon background = new ImageIcon("images/match.png");
   public BufferedImage myImage;
   private Graphics myBuffer;
   battleGame battle;
   private JLabel btext = new JLabel("Defeat Shrek!");
   private boolean trueFrame = false;
   
   public battlePanel()
   {
      battle = new battleGame();
      setLayout(new BorderLayout());
      JPanel p = new JPanel();
      p.setLayout(new GridLayout(1,1));
      btext.setHorizontalAlignment(SwingConstants.CENTER);
      btext.setFont(new Font("Serif", Font.BOLD, 20)); 
      p.add(btext);
      add(p, BorderLayout.SOUTH);
      add(battle);      
      //battle.begin();
      battle.requestFocusInWindow();
   }
   
   public void getStatus()
   {
      trueFrame = battle.getWinner();
   }
   
   public boolean returnPanel()
   {
      return trueFrame;
   }
}