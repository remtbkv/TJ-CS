import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Guy implements Obstacle {
    private ImageIcon i = new ImageIcon("images/wing.png");
    private int x, y, mydx=0, mydy=0, sizeX=75, sizeY=75, bleed=25;

    public Guy(int sx, int sy) {
        x = sx*75;
        y = sy*75;
    }

    public void hop(int mydx, int mydy) {
        if (x + mydx < 0) {
            x = 1200 - sizeX;
        }
        else if (x + mydx > 1200 - sizeX) {
            x = 0;
        }
        else {
            x += mydx;
        }
        if (y + mydy < 0) {
            y = 700 - sizeY - bleed;
        }
        else if (y + mydy > 700 - sizeY - bleed) {
            y = 0;
        }
        else {
            y += mydy;
        }

        // if (d == 1) {
        //     y -= 75;
        // }
        // else if (d == 2) {
        //     y += 75;
        // }
        // else if (d == 3) {
        //     x -= 75;
        // }
        // else if (d == 4) {
        //     x += 75;
        // }
    }

    public void setXY(int sx, int sy) {
        x = sx*75;
        y = sy*75;
    }

    public int getX() {
        return x/75;
    }

    public int getY() {
        return y/75;
    }

    public void setdx(int dx) {
        mydx = dx;
    }

    public void setdy(int dy) {
        mydy = dy;
    }

    public void draw(Graphics myBuffer) {
        myBuffer.drawImage(i.getImage(), x, y, sizeX, sizeY, null);
    }
}