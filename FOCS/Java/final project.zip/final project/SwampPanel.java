import javax.swing.*;
import javax.swing.Timer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.awt.Color;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;
import java.lang.Thread;

public class SwampPanel extends JPanel {
    private BufferedImage myImage;
    private Graphics myBuffer;
    private Guy kaneki;
    private Mob monster;
    private Tentacle tents1, tents2;
    private Pit hole1, hole2;
    private Coin btc1, btc2, btc3, btc4, btc5;
    private Arrow shoot;
    private Timer shot, w1, w2, p1, p2;
    private Color[][] arr;
    public JFrame town = new JFrame("town");
    private TownPanel tpl = new TownPanel();
    Map<String, String> hazards;
    private ArrayList<int[]> open, tcoords;
    private HashSet<int[]> mmnear, ssnear;
    private String[] tnear, mnear, snear;
    private int[][] ttnear, mmnear1, mmnear2, ssnear1, aanear, c1near, c2near, c3near, c4near, c5near;
    private int[] curr, tent1, tent2, mud1, mud2, arro, shrek, u, d, l, r, kpos, spos, c1, c2, c3, c4, c5;
    private int rand, gold;
    private boolean pro = true, aro, arrow, won, missed, alive, sdead, mdead1, mdead2, tdead1, tdead2, t1c, t2c, c1c, c2c, c3c, c4c, c5c;
    private String status;
    private boolean close = false;

    public SwampPanel() {
        myImage = new BufferedImage(1200, 700, BufferedImage.TYPE_INT_RGB);
        myBuffer = myImage.getGraphics();
        myBuffer.drawImage(new ImageIcon("images/swamp.png").getImage(), 0, 0, 1200, 700, null);
        repaint();
        reset();
        addKeyListener(new Key());
        setFocusable(true);
        shot = new Timer(5, new shotListener());
        w1 = new Timer(1, new w1Listener());
        w1.setInitialDelay(500);
        w1.setRepeats(false);
        w2 = new Timer(1, new w2Listener());
        w2.setInitialDelay(1000);
        w2.setRepeats(false);
        p1 = new Timer(1, new p1Listener());
        p1.setInitialDelay(500);
        p1.setRepeats(false);
        p2 = new Timer(1, new p2Listener());
        p2.setInitialDelay(1000);
        p2.setRepeats(false);
    }

    public void paintComponent(Graphics g) {
        g.drawImage(myImage, 0, 0, getWidth(), getHeight(), null);
    }

    public String getStatus() {
        if (won) {
            return "YOU WON!";
        }
        if (missed) {
            return "MISSED! YOU LOST!";
        }
        if (pro) {
            return "STATUS";
        }
        if (status == null) {
            return "STATUS: Safe";
        }
        return status;
    }

    public String getGold() {
        return String.valueOf(gold);
    }

    public String getArrow() {
        if (arrow) {
            return "True";
        }
        else {
            return "False";
        }
    }

    public void remover(int[] pos, ArrayList<int[]> coord) {
        Iterator<int[]> itr = coord.iterator();
        while (itr.hasNext()) {
            if (Arrays.equals(itr.next(), pos)) {
                itr.remove();
            }
        }
    }

    public void blank() {
        myBuffer.setColor(new Color(94, 158, 50));
        // myBuffer.setColor(new Color(209, 209, 209));
        myBuffer.fillRect(0, 0, 1200, 675);

        myBuffer.setColor(new Color(239, 238, 239));
        myBuffer.fillRect(0, 675, 1200, 25);

        int numcols = myImage.getWidth();
        int numrows = myImage.getHeight();
        arr = new Color[numrows][numcols];
        for (int j = 0; j < arr.length; j++) {
            for (int k = 0; k < arr[0].length; k++) {
                arr[j][k] = new Color(myImage.getRGB(k, j));
            }
        }

        for (int k = 0; k < arr[0].length; k++) {
            arr[675][k] = new Color(0, 0, 0);
        }

        for (int j = 0; j < arr.length; j++) {
            for (int k = 0; k < arr[0].length; k++) {
                Color tmp = arr[j][k];
                myImage.setRGB(k, j, tmp.getRGB());
            }
        }
    }

    public void reset() {
        gold = 0;
        missed = won = pro = sdead = mdead1 = mdead2 = tdead1 = tdead2 = arrow = aro = t1c = t2c = c1c = c2c = c3c = c4c = c5c = false;
        alive = true;
        open = new ArrayList<int[]>();
        tcoords = new ArrayList<int[]>();
        mmnear = new HashSet<int[]>();
        ssnear = new HashSet<int[]>();
        hazards = new HashMap<String, String>();
        tnear = mnear = snear = new String[4];
    }

    public void builder() {
        for (int x = 0; x < 16; x++) {
            for (int y = 0; y < 9; y++) {
                open.add(new int[]{x, y});
                tcoords.add(new int[]{x, y});
            }
        }

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        tent1 = tcoords.get(rand);
        hazards.put(Arrays.toString(tent1), "The tentacles have transported you to another location!");
        ttnear = new int[][]{new int[]{(tent1[0] + 1) % 16, tent1[1]}, new int[]{(tent1[0] + 2) % 16, tent1[1]}, new int[]{(tent1[0] - 1) % 16, tent1[1]}, new int[]{(tent1[0] - 2) % 16, tent1[1]}, new int[]{tent1[0], (tent1[1] + 1) % 9}, new int[]{tent1[0], (tent1[1] + 2) % 9}, new int[]{tent1[0], (tent1[1] - 1) % 9}, new int[]{tent1[0], (tent1[1] - 2) % 9}, new int[]{(tent1[0] + 1) % 16, (tent1[1] - 1) % 9}, new int[]{(tent1[0] + 1) % 16, (tent1[1] + 1) % 9}, new int[]{(tent1[0] - 1) % 16, (tent1[1] - 1) % 9}, new int[]{(tent1[0] - 1) % 16, (tent1[1] + 1) % 9}};
        for (int[] tempc : ttnear) {
            hazards.put(Arrays.toString(tempc), "You feel something slither up your leg...");
            remover(tempc, tcoords);
        }
        remover(tent1, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        tent2 = tcoords.get(rand);
        hazards.put(Arrays.toString(tent2), "The tentacles have transported you to another location!");
        ttnear = new int[][]{new int[]{(tent2[0] + 1) % 16, tent2[1]}, new int[]{(tent2[0] + 2) % 16, tent2[1]}, new int[]{(tent2[0] - 1) % 16, tent2[1]}, new int[]{(tent2[0] - 2) % 16, tent2[1]}, new int[]{tent2[0], (tent2[1] + 1) % 9}, new int[]{tent2[0], (tent2[1] + 2) % 9}, new int[]{tent2[0], (tent2[1] - 1) % 9}, new int[]{tent2[0], (tent2[1] - 2) % 9}, new int[]{(tent2[0] + 1) % 16, (tent2[1] - 1) % 9}, new int[]{(tent2[0] + 1) % 16, (tent2[1] + 1) % 9}, new int[]{(tent2[0] - 1) % 16, (tent2[1] - 1) % 9}, new int[]{(tent2[0] - 1) % 16, (tent2[1] + 1) % 9}};
        for (int[] tempc : ttnear) {
            hazards.put(Arrays.toString(tempc), "You feel something slither up your leg...");
            remover(tempc, tcoords);
        }
        remover(tent2, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        mud1 = tcoords.get(rand);
        hazards.put(Arrays.toString(mud1), "The mud has collapsed!");
        mmnear1 = new int[][]{new int[]{(mud1[0] + 1) % 16, mud1[1]}, new int[]{(mud1[0] + 2) % 16, mud1[1]}, new int[]{(mud1[0] - 1) % 16, mud1[1]}, new int[]{(mud1[0] - 2) % 16, mud1[1]}, new int[]{mud1[0], (mud1[1] + 1) % 9}, new int[]{mud1[0], (mud1[1] + 2) % 9}, new int[]{mud1[0], (mud1[1] - 1) % 9}, new int[]{mud1[0], (mud1[1] - 2) % 9}, new int[]{(mud1[0] + 1) % 16, (mud1[1] - 1) % 9}, new int[]{(mud1[0] + 1) % 16, (mud1[1] + 1) % 9}, new int[]{(mud1[0] - 1) % 16, (mud1[1] - 1) % 9}, new int[]{(mud1[0] - 1) % 16, (mud1[1] + 1) % 9}};
        for (int[] tempc : mmnear1) {
            hazards.put(Arrays.toString(tempc), "You feel the ground hardening beneath you...");
            remover(tempc, tcoords);
        }
        remover(mud1, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        mud2 = tcoords.get(rand);
        hazards.put(Arrays.toString(mud2), "The mud has collapsed!");
        mmnear2 = new int[][]{new int[]{(mud2[0] + 1) % 16, mud2[1]}, new int[]{(mud2[0] + 2) % 16, mud2[1]}, new int[]{(mud2[0] - 1) % 16, mud2[1]}, new int[]{(mud2[0] - 2) % 16, mud2[1]}, new int[]{mud2[0], (mud2[1] + 1) % 9}, new int[]{mud2[0], (mud2[1] + 2) % 9}, new int[]{mud2[0], (mud2[1] - 1) % 9}, new int[]{mud2[0], (mud2[1] - 2) % 9}, new int[]{(mud2[0] + 1) % 16, (mud2[1] - 1) % 9}, new int[]{(mud2[0] + 1) % 16, (mud2[1] + 1) % 9}, new int[]{(mud2[0] - 1) % 16, (mud2[1] - 1) % 9}, new int[]{(mud2[0] - 1) % 16, (mud2[1] + 1) % 9}};
        for (int[] tempc : mmnear2) {
            hazards.put(Arrays.toString(tempc), "You feel the ground hardening beneath you...");
            remover(tempc, tcoords);
        }
        remover(mud2, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        shrek = tcoords.get(rand);
        hazards.put(Arrays.toString(shrek), "Mini-Shrek has devoured you!");
        ssnear1 = new int[][]{new int[]{(shrek[0] + 1) % 16, shrek[1]}, new int[]{(shrek[0] + 2) % 16, shrek[1]}, new int[]{(shrek[0] - 1) % 16, shrek[1]}, new int[]{(shrek[0] - 2) % 16, shrek[1]}, new int[]{shrek[0], (shrek[1] + 1) % 9}, new int[]{shrek[0], (shrek[1] + 2) % 9}, new int[]{shrek[0], (shrek[1] - 1) % 9}, new int[]{shrek[0], (shrek[1] - 2) % 9}, new int[]{(shrek[0] + 1) % 16, (shrek[1] - 1) % 9}, new int[]{(shrek[0] + 1) % 16, (shrek[1] + 1) % 9}, new int[]{(shrek[0] - 1) % 16, (shrek[1] - 1) % 9}, new int[]{(shrek[0] - 1) % 16, (shrek[1] + 1) % 9}};
        for (int[] tempc : ssnear1) {
            hazards.put(Arrays.toString(tempc), "You catch a whiff of Shrek's foul odor...");
            remover(tempc, tcoords);
        }
        remover(shrek, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        arro = tcoords.get(rand);
        hazards.put(Arrays.toString(arro), "You have found an arrow!");
        aanear = new int[][]{new int[]{(arro[0] + 1) % 16, arro[1]}, new int[]{(arro[0] - 1) % 16, arro[1]}, new int[]{arro[0], (arro[1] + 1) % 9}, new int[]{arro[0], (arro[1] - 1) % 9}};
        for (int[] tempc : aanear) {
            remover(tempc, tcoords);
        }
        remover(arro, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        c1 = tcoords.get(rand);
        hazards.put(Arrays.toString(c1), "You have found a gold coin!");
        c1near = new int[][]{new int[]{(c1[0] + 1) % 16, c1[1]}, new int[]{(c1[0] - 1) % 16, c1[1]}, new int[]{c1[0], (c1[1] + 1) % 9}, new int[]{c1[0], (c1[1] - 1) % 9}};
        for (int[] tempc : c1near) {
            remover(tempc, tcoords);
        }
        remover(c1, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        c2 = tcoords.get(rand);
        hazards.put(Arrays.toString(c2), "You have found a gold coin!");
        c2near = new int[][]{new int[]{(c2[0] + 1) % 16, c2[1]}, new int[]{(c2[0] - 1) % 16, c2[1]}, new int[]{c2[0], (c2[1] + 1) % 9}, new int[]{c2[0], (c2[1] - 1) % 9}};
        for (int[] tempc : c2near) {
            remover(tempc, tcoords);
        }
        remover(c2, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        c3 = tcoords.get(rand);
        hazards.put(Arrays.toString(c3), "You have found a gold coin!");
        c3near = new int[][]{new int[]{(c3[0] + 1) % 16, c3[1]}, new int[]{(c3[0] - 1) % 16, c3[1]}, new int[]{c3[0], (c3[1] + 1) % 9}, new int[]{c3[0], (c3[1] - 1) % 9}};
        for (int[] tempc : c3near) {
            remover(tempc, tcoords);
        }
        remover(c3, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        c4 = tcoords.get(rand);
        hazards.put(Arrays.toString(c4), "You have found a gold coin!");
        c4near = new int[][]{new int[]{(c4[0] + 1) % 16, c4[1]}, new int[]{(c4[0] - 1) % 16, c4[1]}, new int[]{c4[0], (c4[1] + 1) % 9}, new int[]{c4[0], (c4[1] - 1) % 9}};
        for (int[] tempc : c4near) {
            remover(tempc, tcoords);
        }
        remover(c4, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        c5 = tcoords.get(rand);
        hazards.put(Arrays.toString(c5), "You have found a gold coin!");
        c5near = new int[][]{new int[]{(c5[0] + 1) % 16, c5[1]}, new int[]{(c5[0] - 1) % 16, c5[1]}, new int[]{c5[0], (c5[1] + 1) % 9}, new int[]{c5[0], (c5[1] - 1) % 9}};
        for (int[] tempc : c5near) {
            remover(tempc, tcoords);
        }
        remover(c5, tcoords);

        rand = ThreadLocalRandom.current().nextInt(0, tcoords.size());
        spos = tcoords.get(rand);
    } // tent1 hints do not loop around 16x9 properly

    public void check() {
        if (Arrays.equals(curr, tent1) && !t1c) {
            t1c = true;
            curr = new int[]{ThreadLocalRandom.current().nextInt(0, 16), ThreadLocalRandom.current().nextInt(0, 9)};
            kaneki.setXY(curr[0], curr[1]);
            remover(curr, open);
        }
        if (Arrays.equals(curr, tent2) && !t2c) {
            t2c = true;
            curr = new int[]{ThreadLocalRandom.current().nextInt(0, 16), ThreadLocalRandom.current().nextInt(0, 9)};
            kaneki.setXY(curr[0], curr[1]);
            remover(curr, open);
        }
        if (Arrays.equals(curr, shrek) || Arrays.equals(curr, mud1) || Arrays.equals(curr, mud2) || Arrays.equals(curr, tent1) && t1c || Arrays.equals(curr, tent2) && t2c) {
            alive = false;
            status = hazards.get(Arrays.toString(curr));
            gold = 0;
            if (Arrays.equals(curr, shrek)) {
                sdead = true;
            }
            else if (Arrays.equals(curr, mud1)) {
                mdead1 = true;
            }
            else if (Arrays.equals(curr, mud2)) {
                mdead2 = true;
            }
            else if (Arrays.equals(curr, tent1) && t1c) {
                tdead1 = true;
            }
            else if (Arrays.equals(curr, tent2) && t2c) {
                tdead2 = true;
            }
        }
        if (Arrays.equals(curr, arro) && !aro) {
            aro = true;
            hazards.remove(Arrays.toString(arro), "You have found an arrow!");
        }
        if (Arrays.equals(curr, c1) && !c1c) {
            c1c = true;
            gold += 15;
            hazards.remove(Arrays.toString(c1), "You have found a gold coin!");
        }
        if (Arrays.equals(curr, c2) && !c2c) {
            c2c = true;
            gold += 15;
            hazards.remove(Arrays.toString(c2), "You have found a gold coin!");
        }
        if (Arrays.equals(curr, c3) && !c3c) {
            c3c = true;
            gold += 15;
            hazards.remove(Arrays.toString(c3), "You have found a gold coin!");
        }
        if (Arrays.equals(curr, c4) && !c4c) {
            c4c = true;
            gold += 15;
            hazards.remove(Arrays.toString(c4), "You have found a gold coin!");
        }
        if (Arrays.equals(curr, c5) && !c5c) {
            c5c = true;
            gold += 15;
            hazards.remove(Arrays.toString(c5), "You have found a gold coin!");
        }
    }

    public void drawAll() { // has easy mode visualizer for status
        blank();
        monster.draw(myBuffer);
        hole1.draw(myBuffer);
        hole2.draw(myBuffer);
        tents1.draw(myBuffer);
        tents2.draw(myBuffer);

        for (int[] tempc : open) {
            myBuffer.setColor(new Color(209, 209, 209));
            myBuffer.fillRect(tempc[0] * 75, tempc[1] * 75, 75, 75);
        }

        // easy mode visualizer for status
        for (int[] mmc : mmnear1) {
            if (Arrays.equals(curr, mmc)) {
                mmnear.add(curr);
            }
        }
        for (int[] mmc : mmnear2) {
            if (Arrays.equals(curr, mmc)) {
                mmnear.add(curr);
            }
        }
        for (int[] ssc : ssnear1) {
            if (Arrays.equals(curr, ssc)) {
                ssnear.add(curr);
            }
        }
        for (int[] close : mmnear) {
            myBuffer.drawImage(new ImageIcon("images/mnear.png").getImage(), close[0] * 75, close[1] * 75, 75, 75, null);
        }
        for (int[] close : ssnear) {
            myBuffer.drawImage(new ImageIcon("images/snear.png").getImage(), close[0] * 75, close[1] * 75, 75, 75, null);
        }

        if (aro && !arrow) {
            shoot.drawStatic(myBuffer);
        }
        if (c1c) {
            btc1.draw(myBuffer);
        }
        if (c2c) {
            btc2.draw(myBuffer);
        }
        if (c3c) {
            btc3.draw(myBuffer);
        }
        if (c4c) {
            btc4.draw(myBuffer);
        }
        if (c5c) {
            btc5.draw(myBuffer);
        }
        if (alive) {
            kaneki.draw(myBuffer);
        }
        repaint();
        if (!alive) {
            blank();
            for (int[] tempc : open) {
                myBuffer.setColor(new Color(209, 209, 209));
                myBuffer.fillRect(tempc[0] * 75, tempc[1] * 75, 75, 75);
            }
            if (sdead) {
                monster.draw(myBuffer);
            }
            else if (mdead1) {
                hole1.draw(myBuffer);
            }
            else if (mdead2) {
                hole2.draw(myBuffer);
            }
            else if (tdead1) {
                tents1.draw(myBuffer);
            }
            else if (tdead2) {
                tents2.draw(myBuffer);
            }
            p1.start();
            p2.start();
        }
    }

    public void begin() {
        blank();
        reset();
        builder();
        kaneki = new Guy(spos[0], spos[1]);
        monster = new Mob(shrek[0], shrek[1]);
        tents1 = new Tentacle(tent1[0], tent1[1]);
        tents2 = new Tentacle(tent2[0], tent2[1]);
        hole1 = new Pit(mud1[0], mud1[1]);
        hole2 = new Pit(mud2[0], mud2[1]);
        curr = new int[]{kaneki.getX(), kaneki.getY()};
        btc1 = new Coin(c1[0], c1[1]);
        btc2 = new Coin(c2[0], c2[1]);
        btc3 = new Coin(c3[0], c3[1]);
        btc4 = new Coin(c4[0], c4[1]);
        btc5 = new Coin(c5[0], c5[1]);
        shoot = new Arrow(arro[0], arro[1]);
        runner();
    }

    public void runner() {
        curr = new int[]{kaneki.getX(), kaneki.getY()};
        remover(curr, open);
        status = hazards.get(Arrays.toString(curr));
        check();
        drawAll();
    }

    private class shotListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int ax = shoot.getX();
            int ay = shoot.getY();
            int mx = monster.getX();
            int my = monster.getY();
            if ((mx <= ax && ax <= mx + 75) && (my <= ay && ay <= my + 75)) {
                won = true;
                w1.start();
                w2.start();
                shot.stop();
            }
            else if (shoot.max() && !missed) {
                missed=true;
                blank();
                for (int[] tempc : open) {
                    myBuffer.setColor(new Color(209, 209, 209));
                    myBuffer.fillRect(tempc[0] * 75, tempc[1] * 75, 75, 75);
                }
                p1.start();
                p2.start();
                shot.stop();
            }
            else {
                drawAll();
                shoot.move();
                shoot.draw(myBuffer);
                repaint();
            }
        }
    }

    private class p1Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            myBuffer.drawImage(new ImageIcon("images/frog.png").getImage(), curr[0] * 75, curr[1] * 75, 75, 75, null);
            repaint();
        }
    }

    private class p2Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            myBuffer.drawImage(new ImageIcon("images/cross.png").getImage(), curr[0] * 75, curr[1] * 75, 75, 75, null);
            repaint();
            p1.stop();
            p2.stop();
        }
    }

    private class w1Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            monster.draw(myBuffer);
            repaint();
        }
    }

    private class w2Listener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            myBuffer.drawImage(new ImageIcon("images/cross.png").getImage(), shrek[0] * 75, shrek[1] * 75, 75, 75, null);
            repaint();
            w2.stop();
            w2.stop();
            town.setSize(1200,700);
            Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
            town.setLocation((int) (size.getWidth()-1200)/2, (int) (size.getHeight()-700)/2);
            town.setContentPane(tpl);
            town.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            town.setVisible(true);
        }
    }

    private class Key extends KeyAdapter {
        public void keyPressed(KeyEvent e) {
            if (alive && !won) {
                if (e.getKeyCode() == KeyEvent.VK_W && aro && !arrow) {
                    arrow = true;
                    shoot.spawn(curr[0], curr[1], 1);
                    shot.start();
                }
                else if (e.getKeyCode() == KeyEvent.VK_S && aro && !arrow) {
                    arrow = true;
                    shoot.spawn(curr[0], curr[1], 2);
                    shot.start();
                }
                else if (e.getKeyCode() == KeyEvent.VK_A && aro && !arrow) {
                    arrow = true;
                    shoot.spawn(curr[0], curr[1], 3);
                    shot.start();
                }
                else if (e.getKeyCode() == KeyEvent.VK_D && aro && !arrow) {
                    arrow = true;
                    shoot.spawn(curr[0], curr[1], 4);
                    shot.start();
                }
                else if (e.getKeyCode() == KeyEvent.VK_UP) {
                    kaneki.hop(0, -75);
                    runner();
                }
                else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
                    kaneki.hop(0, 75);
                    runner();
                }
                else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    kaneki.hop(-75, 0);
                    runner();
                }
                else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    kaneki.hop(75, 0);
                    runner();
                }
            }
        }
    }
}