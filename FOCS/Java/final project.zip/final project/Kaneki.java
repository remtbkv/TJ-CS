import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Kaneki extends JPanel
{
   private ImageIcon kaneki = new ImageIcon("images/kaneki.png");
   private ImageIcon kanekiBR = new ImageIcon("images/bowingKR.png");
   private ImageIcon kanekiBL = new ImageIcon("images/bowingKL.png");
   private int width;
   private int height;
   private int startX;
   private int startY;
   private int dxx = 0;
   private int dyy = 0;
   private int mydy;
   private int mydx;
   private boolean lastR = true;
   private boolean finalBattle = false;
   
   public Kaneki()
   {
      height = 60;
      width = 60;
      startX = 15;
      startY = 15;
   }
   public Kaneki(int x, int y)
   {
     startX = x;
     startY = y;
   }
   
   public void setBattle()
   {
      finalBattle = true;
   }
   
   public void move()
   {
      startX += dxx;
      startY += dyy;
   }
   
   public void stopMovement()
   {
      dxx = 0;
      dyy = 0;
   }
   
   public void changedy(int y)
   {
      mydy = y;
      dyy = mydy;
   }
   
   public void changedx(int x)
   {
      mydx = x;
      dxx = mydx;
   }
   
   public int getX()
   {
      return startX;
   }
   
   public int getY()
   {
      return startY;
   }
   
   public void setY(int y)
   {
      startY += y;
   }
   
   public void setX(int x)
   {
      startX += x;
   }
   
   public int getDxx()
   {
      return dxx;
   }
   
   public boolean facingRight()
   {
      return lastR;
   }
   
   public void draw(Graphics g)
   {
      if (finalBattle == false)
      {
         g.drawImage(kaneki.getImage(), startX, startY, 60, 60, null);
      }
      else
      {
         if (dxx > 0)
         {
            g.drawImage(kanekiBR.getImage(), startX, startY, 60, 60, null);
            lastR = true;
         }
         else if (dxx < 0)
         {
            g.drawImage(kanekiBL.getImage(), startX, startY, 60, 60, null);
            lastR = false;
         }
         else if (dxx == 0)
         {
            if (lastR)
            {
               g.drawImage(kanekiBR.getImage(), startX, startY, 60, 60, null);
            }
            else
            {
               g.drawImage(kanekiBL.getImage(), startX, startY, 60, 60, null);
            }
         }
      }
   }
}