import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class testShop extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   public BufferedImage myImage;
   private Graphics myBuffer;
   shopGame sp;
   public int balance = 10;
   private JLabel label = new JLabel("Welcome to the Shop!");
   private JButton ints = new JButton("Exit!");
   private JTextField money = new JTextField("Balance: " + String.valueOf(balance));
   private Icon basicSword = new ImageIcon("images/bsword.png");
   private JButton bsw = new JButton(basicSword);
   private Icon advSword = new ImageIcon("images/swordart.png");
   private JButton asw = new JButton(advSword);
   private Icon shield = new ImageIcon("images/shield.png");
   private JButton sld = new JButton(shield);
   private Icon rShield = new ImageIcon("images/redshield.png");
   private JButton rsd = new JButton(rShield);
   private Icon arrow = new ImageIcon("images/arrowR.png");
   private JButton arw = new JButton(arrow);
   private Icon bow = new ImageIcon("images/bow.png");
   private JButton bw = new JButton(bow);
   private JLabel p1 = new JLabel("5");
   private JLabel p2 = new JLabel("15");
   private JLabel p3 = new JLabel("5");
   private JLabel p4 = new JLabel("15");
   private JLabel p5 = new JLabel("1");
   private JLabel p6 = new JLabel("10");
   private JLabel d1 = new JLabel("An ancient sword used in battle.");
   private JLabel d2 = new JLabel("A hyper-modern weapon with increased attack.");
   private JLabel d3 = new JLabel("Normal shield.");
   private JLabel d4 = new JLabel("Advanced shield.");
   private JLabel d5 = new JLabel("Needed to use the bow!");
   private JLabel d6 = new JLabel("Long-range weapon.");
   private boolean trueFrame = true;
   
private class close1Listener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          trueFrame = false;
      }
   }  
   
   public boolean returnPanel()
   {
      return trueFrame;
   }

   //private ImageIcon shp = new ImageIcon("images/shop.png");

   public testShop()
   {
      setLayout(new GridLayout(7, 3));
      money.setEditable(false);
      sp = new shopGame();
      money.setFont(new Font("Serif", Font.BOLD, 20));
      label.setFont(new Font("Serif", Font.BOLD, 20));
      ints.setFont(new Font("Serif", Font.BOLD,20));
      ints.setHorizontalAlignment(SwingConstants.CENTER);
      money.setHorizontalAlignment(SwingConstants.CENTER);
      label.setHorizontalAlignment(SwingConstants.CENTER);
      p1.setFont(new Font("Serif", Font.BOLD, 20));
      p2.setFont(new Font("Serif", Font.BOLD, 20));
      p3.setFont(new Font("Serif", Font.BOLD, 20));
      p4.setFont(new Font("Serif", Font.BOLD, 20));
      p5.setFont(new Font("Serif", Font.BOLD, 20));
      p6.setFont(new Font("Serif", Font.BOLD, 20));
      d1.setFont(new Font("Serif", Font.BOLD, 20));
      d2.setFont(new Font("Serif", Font.BOLD, 20));
      d3.setFont(new Font("Serif", Font.BOLD, 20));
      d4.setFont(new Font("Serif", Font.BOLD, 20));
      d5.setFont(new Font("Serif", Font.BOLD, 20));
      d6.setFont(new Font("Serif", Font.BOLD, 20));     
      p1.setHorizontalAlignment(SwingConstants.CENTER);
      p2.setHorizontalAlignment(SwingConstants.CENTER);
      p3.setHorizontalAlignment(SwingConstants.CENTER);
      p4.setHorizontalAlignment(SwingConstants.CENTER);
      p5.setHorizontalAlignment(SwingConstants.CENTER);
      p6.setHorizontalAlignment(SwingConstants.CENTER);
      d1.setHorizontalAlignment(SwingConstants.CENTER);
      d2.setHorizontalAlignment(SwingConstants.CENTER);
      d3.setHorizontalAlignment(SwingConstants.CENTER);
      d4.setHorizontalAlignment(SwingConstants.CENTER);
      d5.setHorizontalAlignment(SwingConstants.CENTER);
      d6.setHorizontalAlignment(SwingConstants.CENTER);
      ints.addActionListener(new close1Listener());
      add(bsw);
      add(p1);
      add(d1);
      add(asw);
      add(p2);
      add(d2);
      add(sld);
      add(p3);
      add(d3);
      add(rsd);
      add(p4);
      add(d4);
      add(arw);
      add(p5);
      add(d5);
      add(bw);
      add(p6);
      add(d6);
      //add imageicon
      //add price
      //add descript.
      // ^ 6 times total
      add(money);
      add(label);
      add(ints);     
   }
}