import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class shopGame extends JPanel
{  
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private BufferedImage myImage;
   private Graphics myBuffer;
   private Timer j;
   private Shop s = new Shop();
   private boolean shopOpen = true;
   public shopGame()
   {
      myImage =  new BufferedImage(1200, 700, BufferedImage.TYPE_INT_RGB);
      myBuffer = myImage.getGraphics();
      //addKeyListener(new Key()); 
      setFocusable(true); 
      j = new Timer(5, new AnimationListener()); 
   }
   
   public void begin()
   {
      j.start();
   }

   public void paintComponent(Graphics g)   
   {
      g.drawImage(myImage, 0, 0, 1200, 700, null);
   }
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   public void animate()
   {
      s.draw(myBuffer);
      repaint();
   }
   
      
   
}