import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;

public class TownGame extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private BufferedImage myImage;
   private Graphics myBuffer;
   public Kaneki k = new Kaneki();
   private Timer t;
   private int trueX;
   private int trueY;
   public battlePanel bpanel = new battlePanel();
   public testShop spanel = new testShop();
   private ImageIcon shp = new ImageIcon("images/shop.png");
   private ImageIcon tn = new ImageIcon("images/town.png");
   public JFrame frame = new JFrame("Shop");
   public JFrame mazer = new JFrame("Maze");
   public JFrame shrek = new JFrame("Shrek");
   private int mazeCount = 0;
   private int shrekCount = 0;
   private Timer mt = new Timer(10, new DisposerM());
   private Timer q = new Timer(10, new Disposer());
   private Timer shr = new Timer(10, new DisposerS());
   private int shopCount = 0;
   private boolean openMaze = false;
   private boolean openShrek = false;
   private boolean openShop = false;
   private mazePanel pmz = new mazePanel();
   
   public TownGame()
   {
      myImage =  new BufferedImage(1200, 700, BufferedImage.TYPE_INT_RGB);
      myBuffer = myImage.getGraphics();
      addKeyListener(new Key()); 
      setFocusable(true); 
      k.draw(myBuffer);
      t = new Timer(5, new AnimationListener()); 
   }
   
   public void begin()
   {
      t.start();
   }
   
   public BufferedImage getBImage()
   {
      return myImage;
   }
   
   public void paintComponent(Graphics g)   
   {
      g.drawImage(myImage, 0, 0, 1200, 700, null);
   }
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   public void inHome()
   {
      int x = k.getX();
      int y = k.getY();
      boolean[] array = new boolean[3];
      array[0] = openDoor(440, 500, 220, 280, x, y);
      array[1] = openDoor(603, 663, 537, 597, x, y);
      array[2] = openDoor(819, 879, 195, 255, x, y);
      for (int h = 0; h < 3; h ++)
      {
         if (array[h] == true)
         {
            if (h == 0 && array[h] == true)
            {
               openShrek = true;
            }
            if (h == 1 && array[h] == true) 
            {
               openMaze = true;
            }
            if (h == 2 && array[h] == true)
            {
               openShop = true;
            }
         }
      }
      
   }
    
   public boolean openDoor(int x1, int x2, int y1, int y2, int xLoc, int yLoc)
   {
      for (int x = x1; x < x2; x ++)
      {
         for (int y = y1; y < y2; y ++)
         {
            if (xLoc == x && yLoc == y)
            {
               return true; 
            }
         }
      }
      return false;  
   }
   
   public void inArea()
   {
      int x = k.getX();
      int y = k.getY();
      int[] array = new int[5];
      int first = directionFinder(330, 537, 30, 228, x, y);
      int second = directionFinder(800, 960, 0, 190, x, y);
      int third = directionFinder(585, 708, 370, 534, x, y);
      int fourth = directionFinder(720, 880, 366, 567, x, y);
      int fifth = directionFinder(990, 1110, 381, 522, x, y);
      array[0] = first;
      array[1] = second;
      array[2] = third;
      array[3] = fourth;
      array[4] = fifth;
      for (int j = 0; j < 5; j ++)
      {
         if (array[j] == 0)
         {
            ;
         }
         if (array[j] == 1)
         {
            k.setY(-3);
         }
         if (array[j] == 2)
         {
            k.setX(-3);
         }
         if (array[j] == 3)
         {
            k.setY(3);
         }
         if (array[j] == 4)
         {
            k.setX(3);
         }
      }     
   }
   
   public int directionFinder(int x1, int x2, int y1, int y2, int locX, int locY)
   {
      //1 character is north (of obstacle)
      //2 west
      //3 south
      //4 east
      for (int x = x1; x < x2; x++)
      {
         for (int y = y1; y < y1 + 3; y ++)
         {
            for (int g = locX; g < locX + 60; g++)
            {
               for (int h = locY + 56; h < locY +60; h++)
               {
                  if (g >= x1 && g <= x2 && h >= y1 && h <= y2)
                  {
                     return 1;
                  }
               }   
            }
         } 
      }
      for (int x = x1; x < x2; x++)
      {
         for (int y = y2 - 3; y < y2; y ++)
         {
            for (int g = locX; g < locX + 60; g++)
            {
               for (int h = locY; h < locY +4; h++)
               {
                  if (g >= x1 && g <= x2 && h >= y1 && h <= y2)
                  {
                     return 3;
                  }
               }   
            }
         } 
      }
   
      for (int x = x1; x < x1 + 4; x++)
      {
         for (int y = y1; y < y2; y ++)
         {
            for (int g = locX + 56; g < locX + 60; g++)
            {
               for (int h = locY; h < locY +60; h++)
               {
                  if (g >= x1 && g <= x2 && h >= y1 && h <= y2)
                  {
                     return 2;
                  }
               }   
            }
         } 
      }
   
      for (int x = x2 - 4; x < x2; x++)
      {
         for (int y = y1; y < y2; y ++)
         {
            for (int g = locX; g < locX + 4; g++)
            {
               for (int h = locY; h < locY +60; h++)
               {
                  if (g >= x1 && g <= x2 && h >= y1 && h <= y2)
                  {
                     return 4;
                  }
               }   
            }
         } 
      }     
      return 0;
   
   }
   
   public boolean checkShopPanel()
   {
      if (spanel.returnPanel())
      {
         return false;
      }  
      else
      {
         return true;
      }
   }
   
   public boolean checkMazePanel()
   {
      if (pmz.returnPanel())
      {
         return false;
         //this means the game is over
      }
      else
      {
         return true;
      }
   }
   
   public boolean checkShrekPanel()
   {
      if (bpanel.returnPanel())
      {
         return true;
         //game won;
      }
      else
      {
         return false;
      }
   }
   
   private class DisposerM implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          if (checkMazePanel() == false)
          {
            mazer.dispose();
            mt.stop();
            t.start();
          }
          else
          {
            ;
          }
      }
   } 
   
   private class DisposerS implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          if (checkShrekPanel() == true)
          {
            shrek.dispose();
            shr.stop();
            t.start();
          }
          else
          {
            ;
          }
      }
   } 
   
   private class Disposer implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          if (checkShopPanel())
          {
            frame.dispose();
            q.stop();
            t.start();
          }
          else
          {
            ;
          }
      }
   }  
   public void animate()
   {
      if (openShop = false && openShrek == false && openMaze == false)
      {
         requestFocusInWindow();
      }
      k.move();    
      inArea(); 
      inHome();
      myBuffer.drawImage(tn.getImage(), 0, 0, 1200, 700, null);
      k.draw(myBuffer);
      repaint();
      if (openShop == true && shopCount == 0)
      {
         t.stop();
         shopCount += 1;
         frame.setSize(1200,700);
         Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
         frame.setLocation((int) (size.getWidth()-1200)/2, (int) (size.getHeight()-700)/2);
         frame.setContentPane(spanel);
         frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         frame.setVisible(true);
         openShop = false;
         q.start();
      }   
      if (openMaze == true && mazeCount == 0)
      {      
         t.stop();
         mazeCount += 1;
         mazer.setSize(1200,700);
         Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
         mazer.setLocation((int) (size.getWidth()-1200)/2, (int) (size.getHeight()-700)/2);
         mazer.setContentPane(pmz);
         mazer.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         mazer.setVisible(true);
         openMaze = false;
         mt.start();
      }
      if (openShrek == true && shrekCount == 0)
      {
         t.stop();
         shrekCount += 1;
         shrek.setSize(1200, 700);
         Dimension size = Toolkit.getDefaultToolkit().getScreenSize();
         shrek.setLocation((int) (size.getWidth()-1200)/2, (int) (size.getHeight()-700)/2);
         shrek.setContentPane(bpanel);
         shrek.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
         shrek.setVisible(true);
         shr.start();
         openShrek = false;
      }
   }
   
   private class Key extends KeyAdapter 
   {
      public void keyPressed(KeyEvent e)  
      {
         if (e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            k.changedy(3);
         }
         if (e.getKeyCode() == KeyEvent.VK_UP)
         {
            k.changedy(-3);
         }
         if (e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            k.changedx(3);
         }
         if (e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            k.changedx(-3);
         }
      }
      public void keyReleased(KeyEvent e)
      {
         if(e.getKeyCode() == KeyEvent.VK_UP)
         {
            k.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_DOWN)
         {
            k.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_RIGHT)
         {
            k.stopMovement();
         }
         if(e.getKeyCode() == KeyEvent.VK_LEFT)
         {
            k.stopMovement();
         }
         if (e.getKeyCode() == KeyEvent.VK_SPACE)
         {
            k.stopMovement();
         }
      }
      
   }
   
}