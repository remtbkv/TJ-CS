import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;

public class testShopDriver
{
   public static void main(String[] args)
   {
      JFrame f = new JFrame("test");
      f.setSize(1200,700);
      f.setLocation(0,0);
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      f.setContentPane(new testShop());
      f.setVisible(true);
   }
}
