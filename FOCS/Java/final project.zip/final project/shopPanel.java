import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class shopPanel extends JPanel
{
   public static final int WIDTH = 420;
   public static final int HEIGHT = 376;
   public BufferedImage myImage;
   private Graphics myBuffer;
   testShop sp;
   public int balance = 0;
   private JTextField money = new JTextField("Balance: " + String.valueOf(balance));
   private JLabel label = new JLabel("Welcome to the Shop!");
   private JButton ints = new JButton("Exit!");
   private ImageIcon shp = new ImageIcon("images/shop.png");
   private boolean trueFrame = true;
   
   public shopPanel()
   {
      setLayout(new BorderLayout());
      sp = new testShop();
      JPanel panel = new JPanel();
      panel.setLayout(new GridLayout(1,3));
      money.setEditable(false);
      money.setFont(new Font("Serif", Font.BOLD, 20));
      label.setFont(new Font("Serif", Font.BOLD, 20));
      ints.setFont(new Font("Serif", Font.BOLD,20));
      ints.setHorizontalAlignment(SwingConstants.CENTER);
      money.setHorizontalAlignment(SwingConstants.CENTER);
      label.setHorizontalAlignment(SwingConstants.CENTER);
      add(panel, BorderLayout.SOUTH);
      add(sp);
      panel.add(money);
      panel.add(label);
      panel.add(ints);  
      ints.addActionListener(new closeListener());
      sp.requestFocusInWindow();
      //sp.begin();  
   }
   
   private class closeListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          trueFrame = false;
      }
   }  
   
   public boolean returnPanel()
   {
      return trueFrame;
   }
}