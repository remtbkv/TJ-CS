import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Pit implements Obstacle {
    private ImageIcon i = new ImageIcon("images/hole.png");;
    private int x, y, sizeX=75, sizeY=75, bleed=25;

    public Pit(int sx, int sy) {
        x = sx*75;
        y = sy*75;
    }

    public int getX() {
        return x/75;
    }

    public int getY() {
        return y/75;
    }

    public void draw(Graphics myBuffer) {
        myBuffer.drawImage(i.getImage(), x, y, sizeX, sizeY, null);
    }
}