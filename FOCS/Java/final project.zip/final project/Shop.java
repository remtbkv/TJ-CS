import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Shop extends JPanel
{
   private ImageIcon shop = new ImageIcon("images/shop.png");
   private int topX;
   private int topY;
   private int botX;
   private int botY;
   
   public Shop()
   {
      topX = 0;
      botX = 0;
      topY = 420;
      botY = 376;
   }
   
   public void draw(Graphics g)
   {
      g.drawImage(shop.getImage(), 0, 0, 630, 564, null);
   }
}
