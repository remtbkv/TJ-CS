import javax.swing.*;
import java.awt.*;

public class Arrow {
    private ImageIcon i = new ImageIcon("images/arrow.png");
    private int x, y, ix, iy, d, width = 10, height = 40, mydy = 0, mydx = 0, bleed = 25;

    public Arrow(int sx, int sy) {
        x = sx * 75;
        y = sy * 75;
    }

    public void spawn(int sx, int sy, int dd) {
        x = ix = sx * 75;
        y = iy = sy * 75;
        d = dd;
        if (d == 1) {
            mydy = -15;
        }
        else if (d == 2) {
            mydy = 15;
        }
        else if (d == 3) {
            mydx = -15;
        }
        else if (d == 4) {
            mydx = 15;
        }
    }

    public void move() {
        x += mydx;
        y += mydy;
    }

    public int getX() {
        if (d == 3) {
            return x - height;
        }
        else if (d == 4) {
            return x + 75 + height;
        }
        else {
            return x + 75 / 2 - width / 2;
        }
    }

    public int getY() {
        if (d == 1) {
            return y - height;
        }
        else if (d == 2) {
            return y + height;
        }
        else {
            return y + 75 / 2 - width / 2;
        }
    }

    public boolean max() {
        return Math.abs(ix-x)>=150 || Math.abs(iy-y)>=150;
    }

    public void drawStatic(Graphics myBuffer) {
        myBuffer.drawImage(i.getImage(), x, y, 75, 75, null);
    }

    public void draw(Graphics myBuffer) {
        myBuffer.setColor(new Color(75, 75, 75));
        if (d == 1) { // up
            myBuffer.fillRect(x + 75 / 2 - width / 2, y - height, width, height);
        }
        else if (d == 2) { // down
            myBuffer.fillRect(x + 75 / 2 - width / 2, y + height, width, height);
        }
        else if (d == 3) { // left
            myBuffer.fillRect(x - height, y + 75 / 2 - width / 2, height, width);
        }
        else if (d == 4) { // right
            myBuffer.fillRect(x + 75 + height, y + 75 / 2 - width / 2, height, width);
        }
    }

}