import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.color.ColorSpace;

public class IntroPanel extends JPanel
{
   
   private int counter = 0;
   private JTextField top = new JTextField("Welcome to Shrek's Swamp!", 100);
   private JButton start;
   public Timer a;
   private boolean canStart = true;
   int ct = 0;
   private Timer z = new Timer(15, new GrayListener());
   
   gamePanel panel;
   
   public IntroPanel()
   {
      setLayout(new BorderLayout()); 
      top.setEditable(false);
   
      start = new JButton("Start Game"); 
      start.addActionListener(new StartListener());
      add(start, BorderLayout.SOUTH);
      top.setFont(new Font("Serif", Font.BOLD, 20));
      top.setHorizontalAlignment(SwingConstants.CENTER);  
      add(top, BorderLayout.NORTH);
      a = new Timer(3000, new AnimationListener()); 
      panel = new gamePanel();
      add(panel);
   
   }
   
   public void gray()
   {
      Color[][] tmp = panel.getArray( panel.getBImage() );
      panel.gray( tmp );
      panel.setImage( panel.getBImage() , tmp );
   }
   
   private class GrayListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         if (ct < 20)
         {
            gray();
            ct += 1;
         }
         else if (ct == 20)
         {
            panel.blackout();
            top.setText("");
            top.setBackground(new Color(0,0,0));
         }
         else
         {
            z.stop();
         }
      }
   }
   private class StartListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         if (canStart == true)
         {
            a.start();
            panel.begin();
         }
         else
         {
            ;
         }
      }
   }
   
   public void check()
   {
      if (panel.getCheck() == true)
      {
         z.start();
      }
      else
      {
         ;
      }
   }
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   public void animate()
   {
      String next = panel.getMessage();
      if (next == "C")
      {
         a.stop();
      }
      else
      {
         top.setText(next);
      }
      check();
   } 


}
