import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.color.ColorSpace;

public class mazePanel extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   private ImageIcon kaneki = new ImageIcon("images/kaneki.png");
   public BufferedImage myImage;
   private Graphics myBuffer;
   private JTextField b;
   private int time = 60;
   private JButton start = new JButton("Start Maze");
   private int money = 0;
   private JTextField gold = new JTextField("Coins: " + String.valueOf(money));
   private Timer t = new Timer(1000, new Countdown());
   private Timer z = new Timer(10, new MoneyChecker());
   private boolean gameDone = false;
   

   mazeGame maze;
   
   public mazePanel()
   {
      setLayout(new BorderLayout());

       b = new JTextField(String.valueOf(time));
       b.setEditable(false);
      JPanel panel = new JPanel();
      panel.setLayout(new GridLayout(1, 3));   
      gold.setFont(new Font("Serif", Font.BOLD, 20));  
      gold.setHorizontalAlignment(SwingConstants.CENTER);
      gold.setEditable(false); 
      b.setFont(new Font("Serif", Font.BOLD, 20));  
      b.setHorizontalAlignment(SwingConstants.CENTER);
      start.setFont(new Font("Serif", Font.BOLD, 20));  
      panel.add(start);
      panel.add(b);
      panel.add(gold);
      maze = new mazeGame();
      add(maze); 
      add(panel, BorderLayout.NORTH);     
      start.addActionListener(new mazeListener());
      
   }
   
   public boolean returnPanel()
   {
      return gameDone;
   }
   
   private class mazeListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          maze.requestFocusInWindow(); 
          maze.begin();
          t.start();
          z.start();
      }
   }  
   
   private class MoneyChecker implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         checkMoney();
         gameOver();
      }
   }
   
   public void checkMoney()
   {
      int x = maze.returnMoney();
      money = x;
      gold.setText("Coins: " + String.valueOf(money));
   }
   
   public void gameOver()
   {
      if (maze.winner())
      {
         t.stop();
         b.setText("You win!");
         gameDone = true;
      }
   }
   private class Countdown implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         time -= 1;
         b.setText(String.valueOf(time));
         if (time == 0)
         {
            t.stop();
            b.setText("You lose!");
            gameDone = true;
         }
         
      }
   }
   
   

}
   
 
      
