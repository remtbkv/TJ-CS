import java.awt.*;

interface Obstacle {
    public int getX();
    public int getY();
    public void draw(Graphics myBuffer);
}