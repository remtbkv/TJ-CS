import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Health extends JPanel
{
   private ImageIcon full = new ImageIcon("images/full.png");
   private ImageIcon eighty = new ImageIcon("images/eighty.png");
   private ImageIcon sixty = new ImageIcon("images/sixty.png");
   private ImageIcon forty = new ImageIcon("images/forty.png");
   private ImageIcon twenty = new ImageIcon("images/twenty.png");
   private ImageIcon zero = new ImageIcon("images/zero.png");
   
   private int width;
   private int height;
   private int startX;
   private int startY;
   private int dxx = 0;
   private int dyy = 0;
   private int mydy;
   private int mydx;
   private boolean dead = false;
   
   private int currentHealth = 100;
   
   public Health()
   {
      width = 60;
      height = 20;
   }
   
   public Health(int x, int y, int w, int h)
   {
      startX = x;
      startY = y;
      width = w;
      height = h;
   }
   
   public void move()
   {
      startX += dxx;
      startY += dyy;
   }
   
   public void stopMovement()
   {
      dxx = 0;
      dyy = 0;
   }
   
   public void changedy(int y)
   {
      mydy = y;
      dyy = mydy;
   }
   
   public void changedx(int x)
   {
      mydx = x;
      dxx = mydx;
   }
   
   public int getX()
   {
      return startX;
   }
   
   public int getY()
   {
      return startY;
   }
   
   public void setY(int y)
   {
      startY += y;
   }
   
   public void setX(int x)
   {
      startX += x;
   }
   
   public boolean death()
   {
      return dead;
   }
   public void setHealth()
   {
      currentHealth -=20;
      if (currentHealth < 0)
      {
         dead = true;
      }
   }
   
   
   public void draw(Graphics g)
   {
      if (currentHealth == 100)
      {
         g.drawImage(full.getImage(), startX, startY, width, height, null);
      }
      else if (currentHealth == 80)
      {
         g.drawImage(eighty.getImage(), startX, startY, width, height, null);
      }
      else if (currentHealth == 60)
      {
         g.drawImage(sixty.getImage(), startX, startY, width, height, null);
      }
      else if (currentHealth == 40)
      {
         g.drawImage(forty.getImage(), startX, startY, width, height, null);
      }
      else if (currentHealth == 20)
      {
         g.drawImage(twenty.getImage(), startX, startY, width, height, null);
      }
      else if (currentHealth == 0)
      {
         g.drawImage(zero.getImage(), startX, startY, width, height, null);
      }
   }

   
   
}