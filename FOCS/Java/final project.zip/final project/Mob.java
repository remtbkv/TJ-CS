import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Mob implements Obstacle {
    private ImageIcon i = new ImageIcon("images/spin.png");
    private int x, y, mydx=0, mydy=0, sizeX=75, sizeY=75, bleed=25;

    public Mob(int sx, int sy) {
        x = sx*75;
        y = sy*75;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setdx(int dx) {
        mydx = dx;
    }

    public void setdy(int dy) {
        mydy = dy;
    }

    public void draw(Graphics myBuffer) {
        myBuffer.drawImage(i.getImage(), x, y, sizeX, sizeY, null);
    }
}