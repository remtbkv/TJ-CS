import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.color.ColorSpace;

public class gamePanel extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 600;
   private static final Color BACKGROUND = new Color(204, 204, 204);
   public BufferedImage myImage;
   private Graphics myBuffer;
   private Timer t;
   private int counter = 0;
   private Random rand = new Random();
   private ImageIcon kaneki = new ImageIcon("images/kaneki.png");
   private ImageIcon back = new ImageIcon("images/background.jpg");
   private ImageIcon shrekky = new ImageIcon("images/shrek.png");
   private boolean check = false;
   private Timer s;
   private int x = 300;
   private int y = 250;
   private int count = 0;

      
   public gamePanel()
   {
      myImage =  new BufferedImage(1200, 600, BufferedImage.TYPE_INT_RGB);
      myBuffer = myImage.getGraphics();
      myBuffer.setColor(BACKGROUND);
      myBuffer.fillRect(0,0,1200,600); 
      myBuffer.drawImage(back.getImage(), 0,0,1200, 600, null);
      t = new Timer(500, new AnimationListener());
      s = new Timer(5, new ShrekListener());
   
   }
   
   private class AnimationListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animate(); 
      }
   }
   
   private class ShrekListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
         animateTwo();
      }
   }
   
   public void animateTwo()
   {
      if (count < 32)
      {
         x += 10;
         myBuffer.drawImage(back.getImage(), 0,0,1200, 600, null);
         myBuffer.drawImage(shrekky.getImage(), x, y, 250, 250, null);
         myBuffer.drawImage( kaneki.getImage() , 850 , 250 , 200, 200, null );
         repaint();
         count += 1;
      }
      else
      {
         s.stop();
      }
   }
   
   public boolean getCheck()
   {
      return check;
   }
   
   public BufferedImage getBImage()
   {
      return myImage;
   }
   public String getMessage()
   {
      if (counter == 0)
      {
         counter += 1;
         myBuffer.drawImage( kaneki.getImage() , 850 , 250 , 200, 200, null );
         return "Your objective is to kill Shrek and escape his swamp!";
      }
      if (counter == 1)
      {
         counter +=1;
         return "I'm not sure where he is now, though...";
      }
      if (counter == 2)
      {
         counter += 1;
         myBuffer.drawImage(shrekky.getImage(), 300, 300, 250, 250, null);
         return "Agh! There he is!";
      }
      if (counter == 3)
      {
         counter += 1;
         s.start();
         return "Run!";
      }
      if (counter == 4)
      {
         s.stop();
         check = true;
         counter += 1;
      }
      if (counter == 5)
      {
         return "C";
      }
      return "";
   }
   
   public void blackout()
   {
      Color c = new Color(0,0,0);
      myBuffer.setColor(c);
      myBuffer.fillRect(0,0,1200,600);    
   }
   
   public Color[][] getArray(BufferedImage img)
   {
      Color[][] arr;
   	
      int numcols = myImage.getWidth();
      int numrows = myImage.getHeight();
   	
      arr = new Color[numrows][numcols];
   	
      for(int j = 0; j < arr.length; j++)
      {
         for(int k = 0; k < arr[0].length; k++)
         {
            int rgb = myImage.getRGB(k,j);
         	
            arr[j][k] = new Color(rgb);
         }
      }
   	
      return arr;
   }

   public void animate()
   {
   
      int a = rand.nextInt(256);
      int b = rand.nextInt(256);
      int c = rand.nextInt(256);
      repaint();     
   }  
   
   
   public void gray(Color[][] arr)
   {
      for(int j = 0; j < arr.length; j++)
      {
         for(int k = 0; k < arr[0].length; k++)
         {
            Color tmp = arr[j][k];
            int color = (int)(Math.round((0.3 * tmp.getRed() + 0.59 * tmp.getGreen() + 0.11 * tmp.getBlue())/3));
            arr[j][k] = new Color( color , color , color );
         }
      }
   }
   
   public void setImage(BufferedImage img, Color[][] arr)
   {
      for(int j = 0; j < arr.length; j++)
      {
         for(int k = 0; k < arr[0].length; k++)
         {
            Color tmp = arr[j][k];
            
            int rgb = tmp.getRGB();
            
            myImage.setRGB(k,j,rgb);
         }
      }
   }
   
   public void paintComponent(Graphics g)   
   {
      g.drawImage(myImage, 0, 0, 1200, 600, null);
   }
   
   public void begin()
   {
      t.start();
   }
}