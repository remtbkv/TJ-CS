import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Bitcoin extends JPanel
{
   private ImageIcon btc = new ImageIcon("images/bitcoin.png");
   private int width;
   private int height;
   private int startX;
   private int startY;
   private boolean done = false;
   private boolean giver = false;
   
   public Bitcoin()
   {
      startX = 500;
      startY = 15;
   }
   public Bitcoin(int h, int w)
   {
      startX = h;
      startY = w;
   }
   
   public boolean canGive()
   {
      if (giver == false)
      {
         return true;
      }
      else
      {
      return false;
      }
   }
   
   public void gone()
   {
      done = true;
      giver = true;
   }
   public void draw(Graphics g)
   {
      if (done == false)
      {
         g.drawImage(btc.getImage(), startX, startY, 20, 20, null);
      }
      else
      {
         ;
      }
   }
   
   public boolean collected(Kaneki k)
   {
      for (int x = k.getX(); x < k.getX() + 60; x ++)
      {
         for (int y = k.getY(); y < k.getY() + 60; y ++)
         {
            for (int h = startX; h < startX + 20; h ++)
            {
               for (int j = startY; j < startY + 20; j ++)
               {
                  if (x == h && y == j)
                  {
                     return true;
                  }
                  else
                  {
                     ;
                  }
               }
            }
         }
      }
      return false;
   }

}