import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class mazeDriver
{
     public static void main(String[] args)
     {
      JFrame frame = new JFrame("Shrek's Swamp");
      frame.setSize(1200, 700);
      frame.setLocation(20, 20);
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.setContentPane(new mazePanel());
      frame.setVisible(true);
     }
}