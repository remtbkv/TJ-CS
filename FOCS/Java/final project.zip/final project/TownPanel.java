import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.util.Random;

public class TownPanel extends JPanel
{
   public static final int WIDTH = 1200;
   public static final int HEIGHT = 700;
   public BufferedImage myImage;
   private Graphics myBuffer;
   TownGame town;
   private int x;
   private int y;
   private String str = "(" + String.valueOf(x) + ", " + String.valueOf(y) + ")";
   private JTextField textf = new JTextField(str);
   private Timer t = new Timer(5, new TownListener());
   
   public TownPanel()
   {
      setLayout(new BorderLayout());
      town = new TownGame();
      add(town);
      JPanel panel = new JPanel();
      panel.setLayout(new GridLayout(1,1));
      panel.add(textf);
      add(panel, BorderLayout.SOUTH);         
      town.requestFocusInWindow();
      town.begin(); 
      t.start();
   }
   
   private class TownListener implements ActionListener
   {
      public void actionPerformed(ActionEvent e)
      {
          x = town.k.getX();
          y = town.k.getY();
          str = "(" + String.valueOf(x) + ", " + String.valueOf(y) + ")";
          textf.setText(str);         
      }
   }  
   
   
   
}