import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class Arrow1 extends JPanel
{
   private ImageIcon arrowL = new ImageIcon("images/arrowL.png");
   private ImageIcon arrowR = new ImageIcon("images/arrowR.png");
   private int width = 50;
   private int height = 10;
   private int startX;
   private int startY;
   private int dxx = 0;
   private boolean facingR = true;
   private boolean lastR = true;
   
   public Arrow1(int x, int y)
   {
       startX = x;
       startY = y;
       dxx = 4;
   }
   
   public boolean hitEnemy(Shrek s)
   {
      for (int x = getX(); x < getX() + 24; x ++)
      {
         for (int y= getY(); y < getY()+ 5; y ++)
         {
            for (int j = s.getX(); j < s.getX() + 170; j++)
            {
               for (int k = s.getY(); k < s.getY() + 218; k ++)
               {
                  if (x == j && y ==k)
                  {
                     return true;
                  }
               }
            }
         }  
      }
      return false;
   }
   
   public void checkR(Kaneki k)
   {
      if (k.facingRight())
      {
         facingR = true;
      }
      else
      {
         facingR = false;
      }
   }
   
   public void setDx(int x)
   {
      dxx = x;
   }
   
   
   public void move()
   {
      if (facingR == true)
      {
         startX += dxx;
      }
      else
      {
         startX -= dxx;
      }
   }
   
   public int getX()
   {
      return startX;
   }
   
   public int getY()
   {
      return startY;
   }
   
   public void draw(Graphics g)
   {
      if (facingR == true)
      {
         g.drawImage(arrowR.getImage(), startX, startY, 24, 5, null);
      }
      else
      {
         g.drawImage(arrowL.getImage(), startX, startY, 24, 5, null);
      }
   }
}