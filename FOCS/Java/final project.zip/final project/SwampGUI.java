import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

public class SwampGUI extends JPanel {
   private SwampPanel gfx;
   private JTextField disp, money, arrow;
   private Timer t;
   private boolean on = false;

   public SwampGUI() {
      setLayout(new BorderLayout());
   
      gfx = new SwampPanel();
      add(gfx);
   
      JPanel south = new JPanel();
      south.setLayout(new GridLayout(1, 3));
   
      JButton start = new JButton("Begin!");
      start.addActionListener(new SwampGUI.startListener());
      start.setFont(new Font("Soulmate", Font.BOLD, 15));
      south.add(start);
   
      disp = new JTextField(gfx.getStatus());
      disp.setHorizontalAlignment(SwingConstants.CENTER);
      disp.setFont(new Font("Soulmate", Font.BOLD, 15));
      disp.setEditable(false);
      south.add(disp);
   
      money = new JTextField("GOLD: "+gfx.getGold());
      money.setHorizontalAlignment(SwingConstants.CENTER);
      money.setFont(new Font("Soulmate", Font.BOLD, 15));
      money.setEditable(false);
      south.add(money);
   
      t = new Timer(5, new statusListener());
      t.start();
   
      add(BorderLayout.SOUTH, south);
   }

   private class startListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         gfx.begin();
         gfx.requestFocusInWindow();
      }
   }
   
   

   private class statusListener implements ActionListener {
      public void actionPerformed(ActionEvent e) {
         disp.setText(gfx.getStatus());
         money.setText("GOLD: "+gfx.getGold());
      }
   }
}